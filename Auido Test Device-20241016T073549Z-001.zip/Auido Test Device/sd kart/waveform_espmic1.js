// Initialize the canvas and audio context
const canvas = document.getElementById('waveformCanvas');
const ctx = canvas.getContext('2d');
const audioContext = new (window.AudioContext || window.webkitAudioContext)();
const canvasWidth = canvas.width;
const canvasHeight = canvas.height;

// Set canvas size
canvas.width = window.innerWidth - 20;  // Adjust width to fit the screen
canvas.height = 300;  // Set fixed height

// Fetch the WAV file from the server
fetch('espmic1.wav')
    .then(response => response.arrayBuffer())
    .then(arrayBuffer => audioContext.decodeAudioData(arrayBuffer))
    .then(audioBuffer => {
        drawWaveform(audioBuffer);
    })
    .catch(error => console.error('Error fetching or decoding audio:', error));

function drawWaveform(audioBuffer) {
    const rawData = audioBuffer.getChannelData(0);  // Get audio data from the first channel
    const sampleRate = audioBuffer.sampleRate;
    const width = canvas.width;
    const height = canvas.height;
    const step = Math.ceil(rawData.length / width);
    const amp = height / 2;

    ctx.clearRect(0, 0, width, height);
    ctx.fillStyle = 'white';
    ctx.fillRect(0, 0, width, height);

    ctx.beginPath();
    ctx.moveTo(0, amp);

    for (let x = 0; x < width; x++) {
        const min = Math.min(...rawData.slice(x * step, (x + 1) * step));
        const max = Math.max(...rawData.slice(x * step, (x + 1) * step));
        ctx.lineTo(x, (1 + min) * amp);
        ctx.lineTo(x, (1 + max) * amp);
    }

    ctx.strokeStyle = 'black';
    ctx.stroke();
}
